package com.example.narayan.event;

public class UserType {

    String type;

    public UserType(String type) {
        this.type = type;
    }


}
